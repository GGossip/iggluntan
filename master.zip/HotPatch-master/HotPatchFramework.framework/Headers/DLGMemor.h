//
//  DLGMemor.h
//  DLGMemor
//
//  Created by Liu Junqi on 4/25/18.
//  Copyright © 2018 DeviLeo. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for DLGMemor.
FOUNDATION_EXPORT double DLGMemorVersionNumber;

//! Project version string for DLGMemor.
FOUNDATION_EXPORT const unsigned char DLGMemorVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DLGMemor/PublicHeader.h>


